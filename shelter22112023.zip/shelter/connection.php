<?php
   $host = "localhost";
   $username  = "root";
   $passwd = "greenwich";
   $dbname = "shelter";

   //Creating a connection
   $con = mysqli_connect($host, $username, $passwd, $dbname);

   // if($con){
   //    print("Connection Established Successfully");
   // }else{
   //    print("Connection Failed ");
   // }
?>

